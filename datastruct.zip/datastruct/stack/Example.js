"use strict"; // 严格模式

// function funcA {
//     console.log(this);
// }