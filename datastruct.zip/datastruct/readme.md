# 数据结构 typescript

数据结构
栈 stuck
FILO First in Last Out
- array 栈顶 连接 存储结构
- ？
设计模式 面向接口的编程 interface type
ADT 抽象数据结构
定义的行为
- 入栈
- 出栈
- 获取栈顶元素
- 判断空栈
- 获取栈的大小
- 输出栈内数据
